function addNotification(type, message) {
  const notifications = JSON.parse(localStorage.getItem("notifications") || "[]");
  notifications.push({ type, message, time: new Date().toLocaleString(), read: false });
  localStorage.setItem("notifications", JSON.stringify(notifications));
}

function getUnreadCount() {
  const notifications = JSON.parse(localStorage.getItem("notifications") || "[]");
  return notifications.filter(n => !n.read).length;
}

function markAllAsRead() {
  const notifications = JSON.parse(localStorage.getItem("notifications") || "[]");
  notifications.forEach(n => n.read = true);
  localStorage.setItem("notifications", JSON.stringify(notifications));
}

function showNotifications() {
  const notifications = JSON.parse(localStorage.getItem("notifications") || "[]");
  const container = document.getElementById("notificationList");
  container.innerHTML = "";

  if (notifications.length === 0) {
    container.innerHTML = "<p>No notifications.</p>";
    return;
  }

  notifications.forEach(n => {
    const div = document.createElement("div");
    div.innerHTML = `<p><strong>${n.type}</strong> - ${n.message} <br><small>${n.time}</small></p><hr>`;
    container.appendChild(div);
  });

  markAllAsRead();
  updateBadge();
}

function updateBadge() {
  const count = getUnreadCount();
  const badge = document.getElementById("notifBadge");
  badge.textContent = count > 0 ? count : "";
}
