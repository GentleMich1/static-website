let subjects = JSON.parse(localStorage.getItem('subjects')) || [];

function renderSubjects() {
  const tableBody = document.querySelector("#subjectTable tbody");
  tableBody.innerHTML = "";
  subjects.forEach((subject, index) => {
    tableBody.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td><input type='text' value='${subject}' onchange='editSubject(${index}, this.value)' /></td>
        <td class='actions'>
          <button onclick="deleteSubject(${index})">Delete</button>
        </td>
      </tr>
    `;
  });
}

function addSubject() {
  const input = document.getElementById("subjectName");
  const name = input.value.trim();
  if (name && !subjects.includes(name)) {
    subjects.push(name);
    localStorage.setItem("subjects", JSON.stringify(subjects));
    input.value = "";
    renderSubjects();
  }
}

function editSubject(index, newName) {
  subjects[index] = newName.trim();
  localStorage.setItem("subjects", JSON.stringify(subjects));
  renderSubjects();
}

function deleteSubject(index) {
  if (confirm("Are you sure?")) {
    subjects.splice(index, 1);
    localStorage.setItem("subjects", JSON.stringify(subjects));
    renderSubjects();
  }
}

function exportPDF() {
  window.print();
}

window.onload = renderSubjects;
