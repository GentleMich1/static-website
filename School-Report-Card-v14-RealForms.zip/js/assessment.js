let students = JSON.parse(localStorage.getItem("students")) || [];
let scores = JSON.parse(localStorage.getItem("scores")) || [];
let subjects = JSON.parse(localStorage.getItem("subjects")) || [];

function renderStudents() {
  const className = document.getElementById("selectClass").value;
  const studentSelect = document.getElementById("selectStudent");
  studentSelect.innerHTML = "";
  students.filter(s => s.class === className).forEach(s => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.text = s.name;
    studentSelect.appendChild(opt);
  });
  renderReportCard();
}

function renderClasses() {
  const classes = [...new Set(students.map(s => s.class))];
  const classSelect = document.getElementById("selectClass");
  classes.forEach(c => {
    const opt = document.createElement("option");
    opt.value = c;
    opt.text = c;
    classSelect.appendChild(opt);
  });
  renderStudents();
}

function renderReportCard() {
  const studentId = document.getElementById("selectStudent").value;
  const student = students.find(s => s.id === studentId);
  const studentScores = scores.filter(s => s.studentId === studentId);

  if (!student) return;

  let html = `
    <h3>Report Card for ${student.name} (${student.id})</h3>
    <p>Class: ${student.class} | Gender: ${student.gender} | Parent: ${student.phone}</p>
    <table>
      <thead>
        <tr>
          <th>Subject</th>
          <th>CA</th>
          <th>Exam</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
  `;

  let total = 0;
  studentScores.forEach(s => {
    html += `
      <tr>
        <td>${s.subject}</td>
        <td>${s.ca}</td>
        <td>${s.exam}</td>
        <td>${s.total}</td>
      </tr>
    `;
    total += s.total;
  });

  const avg = studentScores.length ? (total / studentScores.length).toFixed(2) : 0;

  html += `
      </tbody>
    </table>
    <h4>Total: ${total} | Average: ${avg}</h4>
  `;

  document.getElementById("reportCardSection").innerHTML = html;
}

window.onload = renderClasses;
