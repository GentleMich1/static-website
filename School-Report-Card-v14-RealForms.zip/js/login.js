function login() {
  const userType = document.getElementById('userType').value;
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const message = document.getElementById('loginMessage');

  if (userType === "admin") {
    if (username === "admin" && password === "1234") {
      localStorage.setItem("userType", "admin");
      window.location.href = "pages/admin.html";
    } else {
      message.textContent = "Invalid admin credentials.";
    }
  } else {
    const studentData = JSON.parse(localStorage.getItem("students")) || [];
    const student = studentData.find(s => s.id === username && s.password === password);
    if (student) {
      localStorage.setItem("userType", "student");
      localStorage.setItem("currentStudent", JSON.stringify(student));
      window.location.href = "pages/student.html";
    } else {
      message.textContent = "Invalid student ID or password.";
    }
  }
}
