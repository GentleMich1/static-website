let students = JSON.parse(localStorage.getItem("students")) || [];
let scores = JSON.parse(localStorage.getItem("scores")) || [];
let subjects = JSON.parse(localStorage.getItem("subjects")) || [];

function renderClassDropdown() {
  const classSelect = document.getElementById("spreadsheetClass");
  const uniqueClasses = [...new Set(students.map(s => s.class))];
  uniqueClasses.forEach(cls => {
    const opt = document.createElement("option");
    opt.value = cls;
    opt.text = cls;
    classSelect.appendChild(opt);
  });
  renderSpreadsheet();
}

function renderSpreadsheet() {
  const selectedClass = document.getElementById("spreadsheetClass").value;
  const classStudents = students.filter(s => s.class === selectedClass);

  let html = "<table><thead><tr><th>Name</th>";

  subjects.forEach(sub => {
    html += `<th>${sub} (CA)</th><th>${sub} (Exam)</th><th>${sub} (Total)</th>`;
  });

  html += "<th>Total</th><th>Average</th></tr></thead><tbody>";

  classStudents.forEach(s => {
    const stuScores = scores.filter(sc => sc.studentId === s.id);
    let total = 0;
    let subjectCount = 0;
    html += `<tr><td>${s.name}</td>`;
    subjects.forEach(sub => {
      const score = stuScores.find(sc => sc.subject === sub);
      if (score) {
        html += `<td>${score.ca}</td><td>${score.exam}</td><td>${score.total}</td>`;
        total += score.total;
        subjectCount++;
      } else {
        html += "<td>-</td><td>-</td><td>-</td>";
      }
    });
    const avg = subjectCount ? (total / subjectCount).toFixed(2) : 0;
    html += `<td>${total}</td><td>${avg}</td></tr>`;
  });

  html += "</tbody></table>";
  document.getElementById("spreadsheetTable").innerHTML = html;
}

window.onload = renderClassDropdown;
