let students = JSON.parse(localStorage.getItem("students")) || [];

function renderTotalStudents() {
  const total = students.length;
  const males = students.filter(s => s.gender === "Male").length;
  const females = students.filter(s => s.gender === "Female").length;
  document.getElementById("totalStudentsOutput").innerHTML = `<p>Total Students: <strong>${total}</strong></p>`;
  
  renderGenderRatioChart(males, females);
}

function renderGenderRatioChart(maleCount, femaleCount) {
  const ctx = document.getElementById('genderRatioChart').getContext('2d');
  new Chart(ctx, {
    type: 'pie',
    data: {
      labels: ['Male', 'Female'],
      datasets: [{
        label: 'Gender Ratio',
        data: [maleCount, femaleCount],
        backgroundColor: ['#4e73df', '#f6c23e'],
      }]
    }
  });
}

window.onload = renderTotalStudents;
