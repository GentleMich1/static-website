let students = JSON.parse(localStorage.getItem("students")) || [];
let comments = JSON.parse(localStorage.getItem("comments")) || {};

function renderStudents() {
  const selectedClass = document.getElementById("commentClass").value;
  const studentSelect = document.getElementById("commentStudent");
  studentSelect.innerHTML = "";
  students.filter(s => s.class === selectedClass).forEach(s => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.text = s.name;
    studentSelect.appendChild(opt);
  });
  loadComment();
}

function renderClassDropdown() {
  const classSelect = document.getElementById("commentClass");
  const classes = [...new Set(students.map(s => s.class))];
  classes.forEach(cls => {
    const opt = document.createElement("option");
    opt.value = cls;
    opt.text = cls;
    classSelect.appendChild(opt);
  });
  renderStudents();
}

function loadComment() {
  const studentId = document.getElementById("commentStudent").value;
  const com = comments[studentId] || {};
  document.getElementById("principalComment").value = com.principal || "";
  document.getElementById("teacherComment").value = com.teacher || "";
}

function saveComment() {
  const studentId = document.getElementById("commentStudent").value;
  const principal = document.getElementById("principalComment").value;
  const teacher = document.getElementById("teacherComment").value;
  comments[studentId] = { principal, teacher };
  localStorage.setItem("comments", JSON.stringify(comments));
  alert("Comments saved successfully!");
}

window.onload = renderClassDropdown;
