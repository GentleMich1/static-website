let classes = JSON.parse(localStorage.getItem('classes')) || [];

function renderClasses() {
  const tableBody = document.querySelector("#classTable tbody");
  tableBody.innerHTML = "";
  classes.forEach((className, index) => {
    tableBody.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td><input type='text' value='${className}' onchange='editClass(${index}, this.value)' /></td>
        <td class='actions'>
          <button onclick="deleteClass(${index})">Delete</button>
        </td>
      </tr>
    `;
  });
}

function addClass() {
  const input = document.getElementById("className");
  const name = input.value.trim();
  if (name && !classes.includes(name)) {
    classes.push(name);
    localStorage.setItem("classes", JSON.stringify(classes));
    input.value = "";
    renderClasses();
  }
}

function editClass(index, newName) {
  classes[index] = newName.trim();
  localStorage.setItem("classes", JSON.stringify(classes));
  renderClasses();
}

function deleteClass(index) {
  if (confirm("Are you sure?")) {
    classes.splice(index, 1);
    localStorage.setItem("classes", JSON.stringify(classes));
    renderClasses();
  }
}

function exportPDF() {
  window.print();
}

window.onload = renderClasses;
