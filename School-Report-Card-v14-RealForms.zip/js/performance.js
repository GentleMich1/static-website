let students = JSON.parse(localStorage.getItem("students")) || [];

function updateCounts() {
  const total = students.length;
  const male = students.filter(s => s.gender === "Male").length;
  const female = students.filter(s => s.gender === "Female").length;

  document.getElementById("totalCount").innerText = total;
  document.getElementById("maleCount").innerText = male;
  document.getElementById("femaleCount").innerText = female;

  new Chart(document.getElementById("genderPie"), {
    type: "pie",
    data: {
      labels: ["Male", "Female"],
      datasets: [{
        data: [male, female],
        backgroundColor: ["#36A2EB", "#FF6384"]
      }]
    }
  });

  const classes = [...new Set(students.map(s => s.class))];
  const classStatsDiv = document.getElementById("classStats");
  classStatsDiv.innerHTML = "";

  classes.forEach(cls => {
    const classStudents = students.filter(s => s.class === cls);
    const m = classStudents.filter(s => s.gender === "Male").length;
    const f = classStudents.filter(s => s.gender === "Female").length;
    const div = document.createElement("div");
    div.className = "class-stat";
    div.innerText = `${cls}: Male: ${m}, Female: ${f}`;
    classStatsDiv.appendChild(div);
  });
}

window.onload = updateCounts;
