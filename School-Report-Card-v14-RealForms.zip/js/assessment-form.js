let students = JSON.parse(localStorage.getItem("students")) || [];
let subjects = JSON.parse(localStorage.getItem("subjects")) || [];

function generateForm() {
  const selectedClass = document.getElementById("formClass").value;
  const classStudents = students.filter(s => s.class === selectedClass);
  const output = document.getElementById("formOutput");

  let html = "<table><thead><tr><th>Student Name</th>";
  subjects.forEach(sub => {
    html += `<th>${sub} CA</th><th>${sub} Exam</th>`;
  });
  html += "</tr></thead><tbody>";

  classStudents.forEach(s => {
    html += `<tr><td>${s.name}</td>`;
    subjects.forEach(() => {
      html += `<td></td><td></td>`;
    });
    html += "</tr>";
  });

  html += "</tbody></table>";
  output.innerHTML = html;
}

function renderClassDropdown() {
  const classSelect = document.getElementById("formClass");
  const classes = [...new Set(students.map(s => s.class))];
  classes.forEach(cls => {
    const opt = document.createElement("option");
    opt.value = cls;
    opt.text = cls;
    classSelect.appendChild(opt);
  });
  generateForm();
}

window.onload = renderClassDropdown;
