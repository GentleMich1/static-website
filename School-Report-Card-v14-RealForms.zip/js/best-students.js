let students = JSON.parse(localStorage.getItem("students")) || [];
let scores = JSON.parse(localStorage.getItem("scores")) || [];
let subjects = JSON.parse(localStorage.getItem("subjects")) || [];

function renderClassDropdown() {
  const classSelect = document.getElementById("bestClass");
  const classes = [...new Set(students.map(s => s.class))];
  classes.forEach(cls => {
    const opt = document.createElement("option");
    opt.value = cls;
    opt.text = cls;
    classSelect.appendChild(opt);
  });
  renderBestStudents();
}

function renderBestStudents() {
  const selectedClass = document.getElementById("bestClass").value;
  const classStudents = students.filter(s => s.class === selectedClass);
  let performance = [];

  classStudents.forEach(s => {
    const stuScores = scores.filter(sc => sc.studentId === s.id);
    const total = stuScores.reduce((sum, sc) => sum + sc.total, 0);
    const average = stuScores.length ? total / stuScores.length : 0;
    performance.push({ name: s.name, average, id: s.id });
  });

  performance.sort((a, b) => b.average - a.average);

  let output = "<h3>Top Students by Average</h3>";
  performance.slice(0, 5).forEach((p, i) => {
    output += `<div class="student-card"><strong>${i + 1}. ${p.name}</strong> - Avg: ${p.average.toFixed(2)}</div>`;
  });

  output += "<h3>Top Performers by Subject</h3>";
  subjects.forEach(sub => {
    let top = classStudents.map(s => {
      const sc = scores.find(sc => sc.studentId === s.id && sc.subject === sub);
      return sc ? { name: s.name, total: sc.total } : null;
    }).filter(Boolean).sort((a, b) => b.total - a.total);
    
    if (top[0]) {
      output += `<div class="student-card"><strong>${sub}</strong>: ${top[0].name} (${top[0].total})</div>`;
    }
  });

  document.getElementById("bestStudentsOutput").innerHTML = output;
}

window.onload = renderClassDropdown;
