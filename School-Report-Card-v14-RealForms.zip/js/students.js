let students = JSON.parse(localStorage.getItem('students')) || [];

function generateID() {
  return "ST" + Math.floor(Math.random() * 100000);
}

function addStudent() {
  const name = document.getElementById("studentName").value.trim();
  const studentClass = document.getElementById("studentClass").value.trim();
  const gender = document.getElementById("studentGender").value.trim();
  const parentPhone = document.getElementById("parentPhone").value.trim();
  const passportInput = document.getElementById("studentPassport");

  if (!name || !studentClass || !gender || !parentPhone || !passportInput.files.length) {
    alert("All fields are required.");
    return;
  }

  const reader = new FileReader();
  reader.onload = function(e) {
    const newStudent = {
      id: generateID(),
      name,
      class: studentClass,
      gender,
      phone: parentPhone,
      passport: e.target.result
    };
    students.push(newStudent);
    localStorage.setItem("students", JSON.stringify(students));
    renderStudents();
    clearForm();
  };
  reader.readAsDataURL(passportInput.files[0]);
}

function clearForm() {
  document.getElementById("studentName").value = "";
  document.getElementById("studentClass").value = "";
  document.getElementById("studentGender").value = "";
  document.getElementById("parentPhone").value = "";
  document.getElementById("studentPassport").value = "";
}

function renderStudents() {
  const tableBody = document.querySelector("#studentTable tbody");
  tableBody.innerHTML = "";
  students.forEach((student, index) => {
    tableBody.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td>${student.id}</td>
        <td>${student.name}</td>
        <td>${student.class}</td>
        <td>${student.gender}</td>
        <td>${student.phone}</td>
        <td><img src="${student.passport}" class="passport" /></td>
        <td><button onclick="deleteStudent(${index})">Delete</button></td>
      </tr>
    `;
  });
}

function deleteStudent(index) {
  if (confirm("Are you sure you want to delete this student?")) {
    students.splice(index, 1);
    localStorage.setItem("students", JSON.stringify(students));
    renderStudents();
  }
}

window.onload = renderStudents;
