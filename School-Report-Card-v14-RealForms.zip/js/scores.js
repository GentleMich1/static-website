let scores = JSON.parse(localStorage.getItem('scores')) || [];
let students = JSON.parse(localStorage.getItem('students')) || [];
let subjects = JSON.parse(localStorage.getItem('subjects')) || [];

function populateDropdowns() {
  const studentSelect = document.getElementById("studentId");
  const subjectSelect = document.getElementById("subject");
  studentSelect.innerHTML = "";
  subjectSelect.innerHTML = "";

  students.forEach(s => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.text = `${s.name} (${s.id})`;
    studentSelect.add(opt);
  });

  subjects.forEach(sub => {
    const opt = document.createElement("option");
    opt.value = sub;
    opt.text = sub;
    subjectSelect.add(opt);
  });
}

function addScore() {
  const studentId = document.getElementById("studentId").value;
  const subject = document.getElementById("subject").value;
  const ca = parseInt(document.getElementById("caScore").value);
  const exam = parseInt(document.getElementById("examScore").value);

  if (!studentId || !subject || isNaN(ca) || isNaN(exam)) {
    alert("Please fill all fields.");
    return;
  }

  const total = ca + exam;
  const existingIndex = scores.findIndex(s => s.studentId === studentId && s.subject === subject);
  if (existingIndex !== -1) {
    scores[existingIndex].ca = ca;
    scores[existingIndex].exam = exam;
    scores[existingIndex].total = total;
  } else {
    scores.push({ studentId, subject, ca, exam, total });
  }

  localStorage.setItem("scores", JSON.stringify(scores));
  renderScores();
}

function renderScores() {
  const tableBody = document.querySelector("#scoreTable tbody");
  tableBody.innerHTML = "";
  scores.forEach((s, i) => {
    tableBody.innerHTML += `
      <tr>
        <td>${i + 1}</td>
        <td>${s.studentId}</td>
        <td>${s.subject}</td>
        <td>${s.ca}</td>
        <td>${s.exam}</td>
        <td>${s.total}</td>
        <td><button onclick="deleteScore(${i})">Delete</button></td>
      </tr>
    `;
  });
}

function deleteScore(index) {
  if (confirm("Are you sure?")) {
    scores.splice(index, 1);
    localStorage.setItem("scores", JSON.stringify(scores));
    renderScores();
  }
}

window.onload = () => {
  populateDropdowns();
  renderScores();
};
